// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("structure aware fuzz\n", stdout);
  return lionss_run_workload("structure-aware-fuzz");
}
