// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("freebsd build\n", stdout);
  return lionss_run_workload("freebsd-build");
}
