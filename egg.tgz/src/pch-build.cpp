// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("pch build\n", stdout);
  return lionss_run_workload("pch-build");
}
