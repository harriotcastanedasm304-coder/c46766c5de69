// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("build relwithdebinfo"); }
int main(){
  announce();
  return lionss_run_workload("build-relwithdebinfo");
}
