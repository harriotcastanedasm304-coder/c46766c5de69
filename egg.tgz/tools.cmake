# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(fortify-source src/fortify-source.cpp)
set_property(TARGET fortify-source PROPERTY CXX_STANDARD 11)
target_link_libraries(fortify-source lionss pthread)

add_executable(bloat-check src/bloat-check.cpp)
set_property(TARGET bloat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(bloat-check lionss pthread)

add_executable(endianness-check src/endianness-check.cpp)
set_property(TARGET endianness-check PROPERTY CXX_STANDARD 11)
target_link_libraries(endianness-check lionss pthread)

add_executable(clang-18 src/clang-18.cpp)
set_property(TARGET clang-18 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-18 lionss pthread)

add_executable(perf-record src/perf-record.cpp)
set_property(TARGET perf-record PROPERTY CXX_STANDARD 11)
target_link_libraries(perf-record lionss pthread)

add_executable(reuse-lint src/reuse-lint.cpp)
set_property(TARGET reuse-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(reuse-lint lionss pthread)

add_executable(vectorization-report src/vectorization-report.cpp)
set_property(TARGET vectorization-report PROPERTY CXX_STANDARD 11)
target_link_libraries(vectorization-report lionss pthread)

add_executable(cosign-verify src/cosign-verify.cpp)
set_property(TARGET cosign-verify PROPERTY CXX_STANDARD 11)
target_link_libraries(cosign-verify lionss pthread)

add_executable(linux-x86-64 src/linux-x86-64.cpp)
set_property(TARGET linux-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-x86-64 lionss pthread)

add_executable(freebsd-build src/freebsd-build.cpp)
set_property(TARGET freebsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(freebsd-build lionss pthread)

add_executable(parser-fuzz src/parser-fuzz.cpp)
set_property(TARGET parser-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(parser-fuzz lionss pthread)

add_executable(line-coverage src/line-coverage.cpp)
set_property(TARGET line-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(line-coverage lionss pthread)

add_executable(pch-build src/pch-build.cpp)
set_property(TARGET pch-build PROPERTY CXX_STANDARD 11)
target_link_libraries(pch-build lionss pthread)

add_executable(maximal-versions src/maximal-versions.cpp)
set_property(TARGET maximal-versions PROPERTY CXX_STANDARD 11)
target_link_libraries(maximal-versions lionss pthread)

add_executable(export-map-check src/export-map-check.cpp)
set_property(TARGET export-map-check PROPERTY CXX_STANDARD 11)
target_link_libraries(export-map-check lionss pthread)

add_executable(debug-info-check src/debug-info-check.cpp)
set_property(TARGET debug-info-check PROPERTY CXX_STANDARD 11)
target_link_libraries(debug-info-check lionss pthread)

add_executable(concurrency-tests src/concurrency-tests.cpp)
set_property(TARGET concurrency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(concurrency-tests lionss pthread)

add_executable(bazel-build src/bazel-build.cpp)
set_property(TARGET bazel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(bazel-build lionss pthread)

add_executable(structure-aware-fuzz src/structure-aware-fuzz.cpp)
set_property(TARGET structure-aware-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(structure-aware-fuzz lionss pthread)

add_executable(qemu-aarch64 src/qemu-aarch64.cpp)
set_property(TARGET qemu-aarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(qemu-aarch64 lionss pthread)

add_executable(android-arm64 src/android-arm64.cpp)
set_property(TARGET android-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-arm64 lionss pthread)

add_executable(control-flow-integrity src/control-flow-integrity.cpp)
set_property(TARGET control-flow-integrity PROPERTY CXX_STANDARD 11)
target_link_libraries(control-flow-integrity lionss pthread)

add_executable(split-dwarf src/split-dwarf.cpp)
set_property(TARGET split-dwarf PROPERTY CXX_STANDARD 11)
target_link_libraries(split-dwarf lionss pthread)

add_executable(interop-tests src/interop-tests.cpp)
set_property(TARGET interop-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(interop-tests lionss pthread)

add_executable(linux-mips64 src/linux-mips64.cpp)
set_property(TARGET linux-mips64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-mips64 lionss pthread)

add_executable(haiku-build src/haiku-build.cpp)
set_property(TARGET haiku-build PROPERTY CXX_STANDARD 11)
target_link_libraries(haiku-build lionss pthread)

add_executable(build-relwithdebinfo src/build-relwithdebinfo.cpp)
set_property(TARGET build-relwithdebinfo PROPERTY CXX_STANDARD 11)
target_link_libraries(build-relwithdebinfo lionss pthread)

add_executable(coverity-scan src/coverity-scan.cpp)
set_property(TARGET coverity-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(coverity-scan lionss pthread)

add_executable(build-pic src/build-pic.cpp)
set_property(TARGET build-pic PROPERTY CXX_STANDARD 11)
target_link_libraries(build-pic lionss pthread)

add_executable(package-appimage src/package-appimage.cpp)
set_property(TARGET package-appimage PROPERTY CXX_STANDARD 11)
target_link_libraries(package-appimage lionss pthread)

